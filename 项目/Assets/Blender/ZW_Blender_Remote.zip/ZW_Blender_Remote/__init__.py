bl_info = {
    "name": "ZW_Tool Remote Control",
    "author": "ZW",
    "version": (1, 1),
    "blender": (4, 0, 0),
    "location": "Add-ons",
    "description": "安装后自动启动 TCP 服务器，允许 ZW_Tool 远程执行代码",
    "category": "System",
}

import bpy
import socket
import threading
import queue

class ZW_Remote_Server:
    def __init__(self):
        self.running = False
        self.queue = queue.Queue()
        self.server_thread = None

    def start(self, port=12346):
        if self.running:
            print("ZW_Tool Remote Server 已在运行")
            return
        
        self.running = True
        self.server_thread = threading.Thread(target=self._run, args=(port,), daemon=True)
        self.server_thread.start()
        
        # 注册定时器处理命令队列
        bpy.app.timers.register(self._process, first_interval=0.05)
        print(f"ZW_Tool Remote Control 已自动启动 → 监听端口 {port}")

    def _run(self, port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(('127.0.0.1', port))
                s.listen(5)
                print(f"ZW_Remote Server 正在监听 127.0.0.1:{port}")
                
                while self.running:
                    try:
                        conn, _ = s.accept()
                        data = conn.recv(8192).decode('utf-8', errors='ignore').strip()
                        if data:
                            self.queue.put(data)
                            print(f"收到 ZW_Tool 命令 ({len(data)} 字符)")
                        conn.close()
                    except:
                        if not self.running:
                            break
            except Exception as e:
                print(f"ZW_Remote Server 启动失败: {e}")

    def _process(self):
        while not self.queue.empty():
            cmd = self.queue.get()
            try:
                exec(cmd, {"bpy": bpy})
                print("ZW_Tool 执行成功")
            except Exception as e:
                print(f"ZW_Tool 执行出错: {e}")
        return 0.05   # 每50ms检查一次队列

    def stop(self):
        self.running = False
        if bpy.app.timers.is_registered(self._process):
            bpy.app.timers.unregister(self._process)

# 全局实例
server = ZW_Remote_Server()

# ====================== 自动启动核心 ======================
def register():
    # 注册（即使不显示按钮也需要）
    print("ZW_Tool Remote Control Add-on 已加载")
    
    # 自动启动服务器（安装后或启用后立即启动）
    bpy.app.timers.register(
        lambda: (server.start(12346), None)[1], 
        first_interval=1.0   # 延迟1秒启动，避免 Blender 初始化冲突
    )

def unregister():
    server.stop()
    print("ZW_Tool Remote Control Add-on 已卸载")

# 如果是直接运行脚本（测试用）
if __name__ == "__main__":
    register()